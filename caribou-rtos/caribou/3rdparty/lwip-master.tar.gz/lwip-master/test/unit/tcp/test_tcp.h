#ifndef LWIP_HDR_TEST_TCP_H__
#define LWIP_HDR_TEST_TCP_H__

#include "../lwip_check.h"

Suite *tcp_suite(void);

#endif
