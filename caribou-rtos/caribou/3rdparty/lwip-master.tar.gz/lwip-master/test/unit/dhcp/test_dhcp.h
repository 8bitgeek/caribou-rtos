#ifndef LWIP_HDR_TEST_DHCP_H__
#define LWIP_HDR_TEST_DHCP_H__

#include "../lwip_check.h"

Suite* dhcp_suite(void);

#endif
