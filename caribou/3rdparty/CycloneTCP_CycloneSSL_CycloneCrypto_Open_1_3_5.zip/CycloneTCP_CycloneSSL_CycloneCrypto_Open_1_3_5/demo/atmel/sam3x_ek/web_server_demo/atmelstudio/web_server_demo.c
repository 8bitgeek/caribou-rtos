/*
 * web_server_demo.c
 *
 * Created: 09/08/2013 10:09:27
 *  Author: EBBZ778
 */ 

#include "sam.h"

/**
 * \brief Application entry point.
 *
 * \return Unused (ANSI-C compatibility).
 */
int main(void)
{
    /* Initialize the SAM system */
    SystemInit();

    WDT->WDT_MR = WDT_MR_WDDIS;

    while (1) 
    {
        //TODO:: Please write your application code 
    }
}
