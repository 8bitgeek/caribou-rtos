#ifndef LWIP_HDR_TEST_DHCP_H
#define LWIP_HDR_TEST_DHCP_H

#include "../lwip_check.h"

Suite* dhcp_suite(void);

#endif
